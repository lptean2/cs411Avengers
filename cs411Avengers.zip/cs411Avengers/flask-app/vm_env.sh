export FLASK_DB_HOST='localhost'
export FLASK_DB_USER='python'
export FLASK_DB_PW=''
export FLASK_DB_NAME='cpidata'
export FLASK_APP=cpi_app
