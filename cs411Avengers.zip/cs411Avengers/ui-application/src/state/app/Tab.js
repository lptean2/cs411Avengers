export const Tab = {
  EXPLORER: 'EXPLORER',
  EDIT: 'EDIT'
};