import RegionSelector from "./RegionSelector";

export default RegionSelector;