import RemoveButton from "./RemoveButton";

export default RemoveButton;