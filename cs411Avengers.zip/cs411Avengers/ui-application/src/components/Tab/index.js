import Tab from "./Tab";

export default Tab;