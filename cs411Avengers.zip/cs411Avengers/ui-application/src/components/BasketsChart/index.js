import BasketsChart from "./BasketsChart";

export default BasketsChart;